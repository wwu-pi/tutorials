﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("HornetQ specific version of Apache NMS for Stomp")]
[assembly: AssemblyDescription("HornetQ specific version of the Apache NMS for Stomp Class Library (.Net Messaging Library Implementation): An implementation of the NMS API for Stomp")]
[assembly: AssemblyCompany("Practical Computer Science")]
[assembly: AssemblyProduct("HornetQ specific version of Apache NMS for Stomp")]
[assembly: AssemblyCopyright("Copyright (C) 2011")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("05d71a24-3524-4673-8875-31e6d7cdc2d0")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.5.1.0")]

package de.wwu.pi;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

@Path("add")
@Produces({"application/json", "application/xml"})
public class AdderResource {
	
	@GET
	@Path("{first}/{second}")
	public AdderResult addTwoNumbers(
			@PathParam("first") final int first,
			@PathParam("second") final int second) {
		return new AdderResult(first, second);
	}
	
}

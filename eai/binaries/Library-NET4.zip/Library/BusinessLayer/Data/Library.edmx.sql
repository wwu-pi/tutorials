
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 03/10/2011 13:05:56
-- Generated from EDMX file: E:\EAI\NET\Library\BusinessLayer\Data\Library.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [LibraryEF];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------


-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'UserSet'
CREATE TABLE [dbo].[UserSet] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(max)  NOT NULL,
    [Address] nvarchar(max)  NULL
);
GO

-- Creating table 'LoanSet'
CREATE TABLE [dbo].[LoanSet] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Date] datetime  NOT NULL,
    [UserId] int  NOT NULL,
    [Copy_Id] int  NOT NULL
);
GO

-- Creating table 'CopySet'
CREATE TABLE [dbo].[CopySet] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [MediumId] int  NOT NULL
);
GO

-- Creating table 'MediumSet'
CREATE TABLE [dbo].[MediumSet] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Title] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'MediumSet_Book'
CREATE TABLE [dbo].[MediumSet_Book] (
    [Author] nvarchar(max)  NULL,
    [ISBN] nvarchar(max)  NULL,
    [Id] int  NOT NULL
);
GO

-- Creating table 'MediumSet_CD'
CREATE TABLE [dbo].[MediumSet_CD] (
    [Artist] nvarchar(max)  NULL,
    [ASIN] nvarchar(max)  NULL,
    [Id] int  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Id] in table 'UserSet'
ALTER TABLE [dbo].[UserSet]
ADD CONSTRAINT [PK_UserSet]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'LoanSet'
ALTER TABLE [dbo].[LoanSet]
ADD CONSTRAINT [PK_LoanSet]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'CopySet'
ALTER TABLE [dbo].[CopySet]
ADD CONSTRAINT [PK_CopySet]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'MediumSet'
ALTER TABLE [dbo].[MediumSet]
ADD CONSTRAINT [PK_MediumSet]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'MediumSet_Book'
ALTER TABLE [dbo].[MediumSet_Book]
ADD CONSTRAINT [PK_MediumSet_Book]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'MediumSet_CD'
ALTER TABLE [dbo].[MediumSet_CD]
ADD CONSTRAINT [PK_MediumSet_CD]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [MediumId] in table 'CopySet'
ALTER TABLE [dbo].[CopySet]
ADD CONSTRAINT [FK_MediumCopy]
    FOREIGN KEY ([MediumId])
    REFERENCES [dbo].[MediumSet]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_MediumCopy'
CREATE INDEX [IX_FK_MediumCopy]
ON [dbo].[CopySet]
    ([MediumId]);
GO

-- Creating foreign key on [Copy_Id] in table 'LoanSet'
ALTER TABLE [dbo].[LoanSet]
ADD CONSTRAINT [FK_CopyLoan]
    FOREIGN KEY ([Copy_Id])
    REFERENCES [dbo].[CopySet]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_CopyLoan'
CREATE INDEX [IX_FK_CopyLoan]
ON [dbo].[LoanSet]
    ([Copy_Id]);
GO

-- Creating foreign key on [UserId] in table 'LoanSet'
ALTER TABLE [dbo].[LoanSet]
ADD CONSTRAINT [FK_UserLoan]
    FOREIGN KEY ([UserId])
    REFERENCES [dbo].[UserSet]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_UserLoan'
CREATE INDEX [IX_FK_UserLoan]
ON [dbo].[LoanSet]
    ([UserId]);
GO

-- Creating foreign key on [Id] in table 'MediumSet_Book'
ALTER TABLE [dbo].[MediumSet_Book]
ADD CONSTRAINT [FK_Book_inherits_Medium]
    FOREIGN KEY ([Id])
    REFERENCES [dbo].[MediumSet]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [Id] in table 'MediumSet_CD'
ALTER TABLE [dbo].[MediumSet_CD]
ADD CONSTRAINT [FK_CD_inherits_Medium]
    FOREIGN KEY ([Id])
    REFERENCES [dbo].[MediumSet]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------
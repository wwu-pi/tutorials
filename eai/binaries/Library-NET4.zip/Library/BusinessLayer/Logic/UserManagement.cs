﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Library.BusinessLayer.Data;

namespace Library.BusinessLayer.Logic
{
    /// <summary>
    /// Application logic for managing users.
    /// </summary>
    public class UserManagement
    {
        /// <summary>
        /// Creates and persists a new user in the library database.
        /// </summary>
        /// <param name="name">User name, required.</param>
        /// <param name="address">User address, optional.</param>
        /// <returns>The newly created user.</returns>
        public User CreateUser(string name, string address)
        {
            if (String.IsNullOrEmpty(name))
                throw new ArgumentNullException("name", "Name must not be null or empty");
            address = String.IsNullOrEmpty(address) ? null : address;

            using (LibraryContainer db = new LibraryContainer())
            {
                User newUser = new User
                {
                    Name = name,
                    Address = address
                };

                db.UserSet.AddObject(newUser);
                db.SaveChanges();
                return newUser;
            }
        }
    }
}

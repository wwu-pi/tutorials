﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using Library.BusinessLayer.Logic;

namespace Library.Web.User
{
    /// <summary>
    /// Code behind of the user creation site.
    /// </summary>
    public partial class Create : System.Web.UI.Page
    {

        #region Fields

        /// <summary>
        /// Business logic for user management.
        /// </summary>
        protected UserManagement mediumManagement;

        /// <summary>
        /// Utility class.
        /// </summary>
        protected ContextHelper helper;

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            // Initialize fields
            mediumManagement = new UserManagement();
            helper = new ContextHelper(Context);
        }

        #region Action listeners

        #region Action listeners: Form buttons

        /// <summary>
        /// Action listener: button create
        /// Creates a new user if the page is valid.
        /// </summary>
        protected void ButtonCreate_Click(object sender, EventArgs e)
        {
            // check if all inputs are valid
            if (Page.IsValid)
            {
                // create new user
                Library.BusinessLayer.Data.User user = mediumManagement.CreateUser(TextBoxName.Text, TextBoxAddress.Text);

                // set forward message
                helper.Message = String.Format("User {0} created!", user.Name);

                // Forward to user management
                Server.Transfer("Management.aspx");
            }
        }

        /// <summary>
        /// Action listener: button reset.
        /// Resets the form data.
        /// </summary>
        protected void ButtonReset_Click(object sender, EventArgs e)
        {
            // reset input fields
            TextBoxName.Text = "";
            TextBoxAddress.Text = "";
        }

        /// <summary>
        /// Action listener: button cancel.
        /// </summary>
        protected void ButtonCancel_Click(object sender, EventArgs e)
        {
            // Forward to user management
            Server.Transfer("Management.aspx");
        }

        #endregion


        /// <summary>
        /// Action listener : navigation button "back".
        /// </summary>
        protected void LinkButtonBack_Click(object sender, EventArgs e)
        {
            // Forward to user management
            Server.Transfer("Management.aspx");
        }

        #endregion
    }
}

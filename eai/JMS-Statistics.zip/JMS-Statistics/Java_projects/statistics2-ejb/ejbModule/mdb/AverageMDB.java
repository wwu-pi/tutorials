package mdb;

import javax.annotation.Resource;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.BytesMessage;
import javax.jms.Session;
import javax.jms.MessageListener;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.Message;
import javax.jms.Connection;
import javax.jms.MessageProducer;

@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Topic"),
		@ActivationConfigProperty(propertyName = "destination", propertyValue = "topic/TaskTopic"),
		@ActivationConfigProperty(propertyName = "DLQMaxResent", propertyValue = "10") })
public class AverageMDB implements MessageListener {
	@Resource(lookup = "java:/JmsXA")
	private ConnectionFactory cf;
	
	public void onMessage(Message m) {
		Connection conn = null;

		try {
			System.out.println("Average-Server: Message received");
			BytesMessage msg = (BytesMessage) m;
			int anz = msg.readInt();
			double result = 0.0;
			for(int i=0;i<anz;i++) 
				result += msg.readDouble();
			result /= anz;

			conn = cf.createConnection();
			conn.start();
			Session session = conn.createSession(false, Session.AUTO_ACKNOWLEDGE);

			Destination replyTo = m.getJMSReplyTo();
			MessageProducer producer = session.createProducer(replyTo);
			BytesMessage reply = session.createBytesMessage();
			reply.setStringProperty("ResultType","Average");
			reply.writeDouble(result);

			producer.send(reply);
		} 
		catch (Exception e) {e.printStackTrace();} 
		finally {
			if (conn != null) {
				try {conn.close();} 
				catch (Exception e) {e.printStackTrace();}}}}
}

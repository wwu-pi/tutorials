﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Library.BusinessLayer.Data;

namespace Library.BusinessLayer.Logic
{
    /// <summary>
    /// Application logic for managing mediums.
    /// </summary>
    public class MediumManagement
    {
        /// <summary>
        /// Checks if a book with the given ISBN already exists.
        /// </summary>
        /// <param name="isbn">The ISBN to check for.</param>
        /// <returns>True, if there is a book with this ISBN in the database.</returns>
        public bool BookExists(string isbn)
        {
            using (LibraryContainer db = new LibraryContainer())
            {
                var count = (from b in db.MediumSet.OfType<Book>()
                             where b.ISBN == isbn
                             select b).Count();

                return count > 0;
            }
        }

        /// <summary>
        /// Creates and persists a new book in the library database.
        /// </summary>
        /// <param name="title">Book title, required</param>
        /// <param name="isbn">Book ISBN, optional. If supplied, must not exist in the database.</param>
        /// <param name="author">Book author, optional.</param>
        /// <returns>The newly created book.</returns>
        public Book CreateBook(string title, string isbn, string author)
        {
            if (String.IsNullOrEmpty(title))
                throw new ArgumentNullException("title", "Must not be null or empty");
            isbn = String.IsNullOrEmpty(isbn) ? null : isbn;
            author = String.IsNullOrEmpty(author) ? null : author;

            if (isbn != null && BookExists(isbn))
                throw new ArgumentException("ISBN already in database", "isbn");

            using (LibraryContainer db = new LibraryContainer())
            {
                Book newBook = new Book
                {
                    Title = title,
                    ISBN = isbn,
                    Author = author
                };

                db.MediumSet.AddObject(newBook);
                db.SaveChanges();
                return newBook;
            }
        }
    }
}

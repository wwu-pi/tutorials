﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using Library.BusinessLayer.Logic;
using Library.BusinessLayer.Data;


namespace Library.Web.Medium
{
    /// <summary>
    /// Code behind of the book creation site.
    /// </summary>
    public partial class CreateBook : System.Web.UI.Page
    {

        #region Fields

        /// <summary>
        /// Business logic for medium management.
        /// </summary>
        protected MediumManagement mediumManagement;

        /// <summary>
        /// Utility class.
        /// </summary>
        protected ContextHelper helper;

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            // Initialize fields
            mediumManagement = new MediumManagement();
            helper = new ContextHelper(Context);
        }

        #region Action listeners

        #region Action listeners: Form buttons

        /// <summary>
        /// Action listener: button create
        /// Creates a new book if the page is valid.
        /// </summary>
        protected void ButtonCreate_Click(object sender, EventArgs e)
        {
            // check if all inputs are valid
            if (Page.IsValid)
            {
                // create new user
                Book book = mediumManagement.CreateBook(TextBoxTitle.Text, TextBoxIsbn.Text, TextBoxAuthor.Text);

                // set forward message
                helper.Message = String.Format("Book {0} created!", book.Title);

                // Forward to user management
                Server.Transfer("Management.aspx");
            }
        }

        /// <summary>
        /// Action listener: button reset.
        /// Resets the form data.
        /// </summary>
        protected void ButtonReset_Click(object sender, EventArgs e)
        {
            // reset input fields
            TextBoxTitle.Text = "";
            TextBoxIsbn.Text = "";
            TextBoxAuthor.Text = "";
        }

        /// <summary>
        /// Action listener: button cancel.
        /// </summary>
        protected void ButtonCancel_Click(object sender, EventArgs e)
        {
            // Forward to book management
            Server.Transfer("Management.aspx");
        }

        #endregion


        /// <summary>
        /// Action listener : navigation button "back".
        /// </summary>
        protected void LinkButtonBack_Click(object sender, EventArgs e)
        {
            // Forward to book management
            Server.Transfer("Management.aspx");
        }

        #endregion

        /// <summary>
        /// Validate callback for isbn.
        /// Checks if the isbn is alreaty in use
        /// </summary>
        protected void CustomValidatorIsbn_ServerValidate(object source, ServerValidateEventArgs args)
        {
            // Validation fails if isbn already in use
            args.IsValid = !mediumManagement.BookExists(args.Value);
        }


    }
}

﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace Library
{
    /// <summary>
    /// Code behind of the master page.
    /// </summary>
    public partial class Site : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Create context helper
            ContextHelper helper = new ContextHelper(Context);

            // get and display forwarded info messages
            String message = helper.Message;
            PanelMessage.Visible = message != null;
            LabelMessage.Text = message;

            // get and display forwarded error messages
            String errorMessage = helper.ErrorMessage;
            PanelErrorMessage.Visible = errorMessage != null;
            LabelErrorMessage.Text = errorMessage;
        }

        #region Action listeners for menu navigation

        /// <summary>
        /// Action listener for menu navigation: Home
        /// </summary>
        protected void LinkHome_Click(object sender, EventArgs e)
        {
            Server.Transfer("~/Main.aspx");
        }

        /// <summary>
        /// Action listener for menu navigation: User management
        /// </summary>
        protected void LinkUserManagement_Click(object sender, EventArgs e)
        {
            Server.Transfer("~/User/Management.aspx");
        }

        /// <summary>
        /// Action listener for menu navigation: Medium management
        /// </summary>
        protected void LinkMediumManagement_Click(object sender, EventArgs e)
        {
            Server.Transfer("~/Medium/Management.aspx");
        }

        #endregion 
    }
}

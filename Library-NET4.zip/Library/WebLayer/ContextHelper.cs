﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace Library
{
    /// <summary>
    /// Provides auxiliary methods for the HttpContext.
    /// </summary>
    public class ContextHelper
    {
        /// <summary>
        /// Context for whom auxiliary methods are provided.
        /// </summary>
        protected HttpContext _context;

        /// <summary>
        /// Constructs a new ContextHelper.
        /// </summary>
        /// <param name="context">Context for whom this auxiliary 
        /// methods</param>
        public ContextHelper(HttpContext context)
        {
            this._context = context;
        }

        #region Properties

        /// <summary>
        /// Message property to get and set an info message.
        /// Can be used to forward info messages to the following page.
        /// </summary>
        public String Message
        {
            get { return (string)_context.Items["message"]; }
            set { _context.Items.Add("message", value); }
        }

        /// <summary>
        /// Error message property to get and set an error message.
        /// Can be used to forward error messages to the following page.
        /// </summary>
        public String ErrorMessage
        {
            get { return (string)_context.Items["errorMessage"]; }
            set { _context.Items.Add("errorMessage", value); }
        }

        #endregion

    }
}

﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

namespace Library.Web.User
{
    /// <summary>
    /// Code behind for the root page of user management.
    /// </summary>
    public partial class Management : System.Web.UI.Page
    {
        /// <summary>
        /// Action listener for the create user function.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void LinkButtonCreateUser_Click(object sender, EventArgs e)
        {
            // Forward to create user page
            Server.Transfer("Create.aspx");
        }
    }
}

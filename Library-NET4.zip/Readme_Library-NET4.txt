Library Application (.NET 4.0)

Technologies:
* C#
* ADO.NET Entity Framework 4.0
* ASP.NET
* (LINQ)

Authors:
* Henning Heitk�tter (Business layer)
* Christian Hermanns (Web layer)

Last update: 2011-03-11

Requirements:
* Visual Studio 2010 (available on MSDNAA - http://msdn40.e-academy.com/elms/Storefront/Home.aspx?campus=wwu_muenster_wiwi)

Instructions:
1. Open the file Library.sln.

= A. Creating the database =
2. Open the "Server Explorer" (under "View" in the menu bar).
3. Right-click on "Data Connections" and select "Create New SQL Server Database...".
4. Set "Server name" to "localhost\sqlexpress" and "New database name" to "LibraryEF". Press OK.

= B. Creating the tables =
5. In the "Solution Explorer", expand "BusinessLayer -> Data" and open the file "Library.edmx.sql".
	- This SQL script was generated from the Entity Data Model "Library.edmx" and creates the necessary tables.
6. Right-click somewhere in the editor and choose "Execute SQL".
7. When asked to connect to a database, set "Server name" and "Connect to database" (press "Options >>", then switch to the tab "Connection Properties") to the respective values from step 4. Click "Connect".

8. Right-click on "WebLayer" in the "Solution Explorer" and select "Set as StartUp Project".
9. Click the green arrow in the toolbar or press "F5" or choose "Debug -> Start Debugging" from the menu bar to start the web application.
	- In order to directly open the main page upon start (instead of the directory listing), select the file "Main.aspx" in the "Solution Explorer" prior to starting the application.
	- The application implements the use cases "Create Book" and "Create User".
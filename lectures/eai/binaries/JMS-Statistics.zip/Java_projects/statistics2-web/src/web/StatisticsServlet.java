package web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.annotation.Resource;
import javax.jms.BytesMessage;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.Topic;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class StatisticsServlet extends HttpServlet {
  private static final long serialVersionUID = 5116801917911899718L;

  @Resource(lookup = "java:/ConnectionFactory")
	private ConnectionFactory cf;
	
	@Resource(lookup = "java:/topic/TaskTopic")
	private Topic topic;
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req,resp);
	}
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		double[] a = new double[3];
		a[0] = Double.parseDouble(req.getParameter("x"));
		a[1] = Double.parseDouble(req.getParameter("y"));
		a[2] = Double.parseDouble(req.getParameter("z"));
		
		PrintWriter out = resp.getWriter();
		
		Double average = null, median = null;
		Connection connection = null;
		try{
			connection = cf.createConnection();
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			
			MessageProducer sender = session.createProducer(topic);
			Queue temporaryQueue = session.createTemporaryQueue();
			BytesMessage message = session.createBytesMessage();
			message.writeInt(a.length);
			for(int i=0; i<a.length;i++) 
			  message.writeDouble(a[i]);
			message.setJMSReplyTo(temporaryQueue);
			sender.send(message);
			
			connection.start();
			
			MessageConsumer consumer = session.createConsumer(temporaryQueue, "ResultType='Average'");
			BytesMessage resultMsg = (BytesMessage) consumer.receive(1000);
			if (resultMsg != null) 
				average = resultMsg.readDouble();
			
			consumer = session.createConsumer(temporaryQueue, "ResultType='Median'");
			resultMsg = (BytesMessage) consumer.receive(1000);
			if (resultMsg != null) 
				median = resultMsg.readDouble();
		}
		catch (Exception e) {e.printStackTrace();}
		finally{
			if(connection!=null)
				try {
					connection.close();
				} catch (JMSException e) {
					e.printStackTrace();
				}
		}
		
		// Ausgabe
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd\">");
		out.println("<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"de\" lang=\"de\">");	
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Statistik</title>");
		out.println("<meta http-equiv=\"content-type\" content=\"text/html;charset=ISO-8859-1\" />");
		out.println("</head>");
		out.println("<body>");
		out.println("Average: "+(average!=null?average:"no result")+"</br>");
		out.println("Median: "+(median!=null?median:"no result")+"</br>");
		out.println("</body>");
		out.println("</html>");
		out.close();
	}
}

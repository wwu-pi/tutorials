﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Apache.NMS;

namespace JmsClient
{
    class Program
    {
        private static ISession session;

        static void Main(string[] args)
        {
            Uri connectUri = new Uri("stomp:tcp://localhost:61613");
            IConnectionFactory factory = new NMSConnectionFactory(connectUri);

            using (IConnection connection = factory.CreateConnection())
            using (session = connection.CreateSession())
            {
                IDestination destination = session.GetDestination("topic://TaskTopic");
                using (IMessageConsumer consumer = session.CreateConsumer(destination))
                {
                    connection.Start();
                    consumer.Listener += new MessageListener(OnMessage);
                    Console.WriteLine("Consumer started, waiting for messages... (Press ENTER to stop.)");

                    Console.ReadLine();
                }
            }
        }

        private static void OnMessage(IMessage message)
        {
            Console.WriteLine("Median-Server (.NET): Message received");

            IBytesMessage msg = (IBytesMessage) message;
            int count = msg.ReadInt32();
            double[] a = new double[count];
            for (int i = 0; i < count; i++)
                a[i] = msg.ReadDouble();

            double result = Median(a);

            IDestination replyTo = msg.NMSReplyTo;
            using (IMessageProducer producer = session.CreateProducer(replyTo))
            {
                IBytesMessage reply = producer.CreateBytesMessage();
                reply.WriteDouble(result);
                reply.Properties.SetString("ResultType", "Median");
                producer.Send(reply);
            }
        }

        private static double Median(double[] a)
        {
            Array.Sort(a);
            return a[a.Length / 2];
        }
    }
}

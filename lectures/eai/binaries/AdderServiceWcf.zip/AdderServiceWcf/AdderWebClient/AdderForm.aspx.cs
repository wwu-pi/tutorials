﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AdderWebClient
{
    public partial class AdderForm : System.Web.UI.Page
    {
        protected void ButtonCalculate_Click(object sender, EventArgs e)
        {
            // Read integer values from text fields
            int v1 = Convert.ToInt32(TextBox1.Text);
            int v2 = Convert.ToInt32(TextBox2.Text);

            // Create adder service proxy
            AdderServiceReference.Adder adderService = new AdderServiceReference.AdderClient();
            
            // Invoke service and display result
            ResultLabel.Text = "Result: " + adderService.Add(v1, v2);
        }
    }
}
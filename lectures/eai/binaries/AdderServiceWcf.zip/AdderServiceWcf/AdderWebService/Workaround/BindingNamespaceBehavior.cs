﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel.Description;

namespace AdderWebService.Workaround
{
    /// <summary>
    /// Enables configuration of binding namespace in code when using Simplified Configuration for WCF.
    /// </summary>
    /// <see cref="http://connect.microsoft.com/wcf/feedback/details/583163/endpoint-bindingnamespace"/>
    class BindingNamespaceBehavior : Attribute, IServiceBehavior
    {
        public string bindingNamespace { get; set; }

        public void AddBindingParameters(ServiceDescription serviceDescription, System.ServiceModel.ServiceHostBase serviceHostBase, System.Collections.ObjectModel.Collection<ServiceEndpoint> endpoints, System.ServiceModel.Channels.BindingParameterCollection bindingParameters)
        {
        }

        public void ApplyDispatchBehavior(ServiceDescription serviceDescription, System.ServiceModel.ServiceHostBase serviceHostBase)
        {
        }

        public void Validate(ServiceDescription serviceDescription, System.ServiceModel.ServiceHostBase serviceHostBase)
        {
            foreach (var endpoint in serviceHostBase.Description.Endpoints)
            {
                endpoint.Binding.Namespace = bindingNamespace;
            }
        }
    }
}
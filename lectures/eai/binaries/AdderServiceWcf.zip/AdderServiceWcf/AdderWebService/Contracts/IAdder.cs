﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace AdderWebService.Contracts
{
    /// <summary>
    /// This service adds two integers.
    /// </summary>
    [ServiceContract(Name="Adder", Namespace = "http://eai.pi.unimuenster.de")] //Name & Namespace: optional
    public interface IAdder
    {
        /// <summary>
        /// Adds the two arguments.
        /// </summary>
        /// <param name="value1">First summand</param>
        /// <param name="value2">Second summand</param>
        /// <returns>Sum of the two summands</returns>
        [OperationContract]
        int Add(int value1, int value2);

        [OperationContract]
        AdditionResult AddWithResult(int value1, int value2);
    }
}

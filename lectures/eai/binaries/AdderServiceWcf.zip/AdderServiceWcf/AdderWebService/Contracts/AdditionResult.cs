﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace AdderWebService.Contracts
{
    [DataContract(Namespace = "http://eai.pi.unimuenster.de")]
    public class AdditionResult
    {
        [DataMember]
        public int FirstSummand { get; set; }
        [DataMember]
        public int SecondSummand { get; set; }
        [DataMember]
        public int Result { get; set; }
    }
}
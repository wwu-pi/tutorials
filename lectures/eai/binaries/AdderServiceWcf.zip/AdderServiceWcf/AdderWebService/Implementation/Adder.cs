﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel;
using AdderWebService.Contracts;
using AdderWebService.Workaround;

namespace AdderWebService.Implementation
{
    [ServiceBehavior(Namespace = "http://eai.pi.unimuenster.de")] // optional, only for namespace
    [BindingNamespaceBehavior(bindingNamespace = "http://eai.pi.unimuenster.de")] // ~
    class Adder : IAdder
    {
        public int Add(int value1, int value2)
        {
            return value1 + value2;
        }

        public AdditionResult AddWithResult(int value1, int value2)
        {
            AdditionResult result = new AdditionResult();
            result.FirstSummand = value1;
            result.SecondSummand = value2;
            result.Result = Add(value1, value2);
            return result;
        }
    }
}